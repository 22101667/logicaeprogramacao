﻿namespace AppLista03
{
    partial class EXERCICIO1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnmedia = new System.Windows.Forms.Button();
            this.btnporct = new System.Windows.Forms.Button();
            this.lblrsoma = new System.Windows.Forms.Label();
            this.lblrmedia = new System.Windows.Forms.Label();
            this.lblrporct = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum1.ForeColor = System.Drawing.Color.LightPink;
            this.lblNum1.Location = new System.Drawing.Point(80, 144);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(46, 16);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "Num1";
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum2.ForeColor = System.Drawing.Color.HotPink;
            this.lblNum2.Location = new System.Drawing.Point(237, 144);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(46, 16);
            this.lblNum2.TabIndex = 1;
            this.lblNum2.Text = "Num2";
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum3.ForeColor = System.Drawing.Color.DeepPink;
            this.lblNum3.Location = new System.Drawing.Point(393, 144);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(46, 16);
            this.lblNum3.TabIndex = 2;
            this.lblNum3.Text = "Num3";
            // 
            // txtNum1
            // 
            this.txtNum1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNum1.Location = new System.Drawing.Point(83, 170);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(118, 20);
            this.txtNum1.TabIndex = 3;
            // 
            // txtNum2
            // 
            this.txtNum2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNum2.Location = new System.Drawing.Point(240, 170);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(118, 20);
            this.txtNum2.TabIndex = 4;
            // 
            // txtNum3
            // 
            this.txtNum3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNum3.Location = new System.Drawing.Point(396, 170);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(118, 20);
            this.txtNum3.TabIndex = 5;
            // 
            // btnSoma
            // 
            this.btnSoma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoma.ForeColor = System.Drawing.Color.White;
            this.btnSoma.Location = new System.Drawing.Point(83, 214);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(137, 38);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "SOMA";
            this.btnSoma.UseVisualStyleBackColor = false;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnmedia
            // 
            this.btnmedia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnmedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmedia.ForeColor = System.Drawing.SystemColors.Window;
            this.btnmedia.Location = new System.Drawing.Point(240, 214);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(133, 38);
            this.btnmedia.TabIndex = 7;
            this.btnmedia.Text = "MÉDIA";
            this.btnmedia.UseVisualStyleBackColor = false;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // btnporct
            // 
            this.btnporct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnporct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnporct.ForeColor = System.Drawing.SystemColors.Info;
            this.btnporct.Location = new System.Drawing.Point(396, 214);
            this.btnporct.Name = "btnporct";
            this.btnporct.Size = new System.Drawing.Size(156, 38);
            this.btnporct.TabIndex = 8;
            this.btnporct.Text = "PORCENTAGEM";
            this.btnporct.UseVisualStyleBackColor = false;
            this.btnporct.Click += new System.EventHandler(this.btnporct_Click);
            // 
            // lblrsoma
            // 
            this.lblrsoma.AutoSize = true;
            this.lblrsoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrsoma.Location = new System.Drawing.Point(51, 20);
            this.lblrsoma.Name = "lblrsoma";
            this.lblrsoma.Size = new System.Drawing.Size(119, 18);
            this.lblrsoma.TabIndex = 9;
            this.lblrsoma.Text = "Resultado Soma";
            // 
            // lblrmedia
            // 
            this.lblrmedia.AutoSize = true;
            this.lblrmedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrmedia.Location = new System.Drawing.Point(454, 20);
            this.lblrmedia.Name = "lblrmedia";
            this.lblrmedia.Size = new System.Drawing.Size(119, 18);
            this.lblrmedia.TabIndex = 10;
            this.lblrmedia.Text = "Resultado Média";
            // 
            // lblrporct
            // 
            this.lblrporct.AutoSize = true;
            this.lblrporct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrporct.Location = new System.Drawing.Point(238, 65);
            this.lblrporct.Name = "lblrporct";
            this.lblrporct.Size = new System.Drawing.Size(168, 18);
            this.lblrporct.TabIndex = 11;
            this.lblrporct.Text = "Resultado Porcentagem";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightBlue;
            this.panel1.Controls.Add(this.lblrporct);
            this.panel1.Controls.Add(this.lblrsoma);
            this.panel1.Controls.Add(this.lblrmedia);
            this.panel1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Location = new System.Drawing.Point(-21, 344);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(891, 126);
            this.panel1.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(50, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 18);
            this.label1.TabIndex = 13;
            this.label1.Text = "EXERCICIO 1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(-21, -9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(688, 110);
            this.panel2.TabIndex = 14;
            // 
            // EXERCICIO1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(643, 450);
            this.Controls.Add(this.btnporct);
            this.Controls.Add(this.btnmedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "EXERCICIO1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Lista03ex1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Button btnporct;
        private System.Windows.Forms.Label lblrsoma;
        private System.Windows.Forms.Label lblrmedia;
        private System.Windows.Forms.Label lblrporct;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
    }
}

