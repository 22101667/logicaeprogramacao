﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class EXERCICIO2 : Form
    {
        public EXERCICIO2()
        {
            InitializeComponent();
        }

        private void btnresult_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtvlrdinheiro.Text);
            float num2 = float.Parse(txtvlrlitro.Text);
            float resultado;
            resultado = num1 / num2;
            lblresult.Text = "A quantidade de litros é: " + resultado;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
