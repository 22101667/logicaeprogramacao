﻿namespace AppLista03
{
    partial class EXERCICIO2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtvlrdinheiro = new System.Windows.Forms.TextBox();
            this.txtvlrlitro = new System.Windows.Forms.TextBox();
            this.lblvlrdinheiro = new System.Windows.Forms.Label();
            this.lblvlrlitro = new System.Windows.Forms.Label();
            this.lblresult = new System.Windows.Forms.Label();
            this.btnresult = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtvlrdinheiro
            // 
            this.txtvlrdinheiro.Location = new System.Drawing.Point(130, 158);
            this.txtvlrdinheiro.Name = "txtvlrdinheiro";
            this.txtvlrdinheiro.Size = new System.Drawing.Size(175, 20);
            this.txtvlrdinheiro.TabIndex = 0;
            // 
            // txtvlrlitro
            // 
            this.txtvlrlitro.Location = new System.Drawing.Point(395, 158);
            this.txtvlrlitro.Name = "txtvlrlitro";
            this.txtvlrlitro.Size = new System.Drawing.Size(157, 20);
            this.txtvlrlitro.TabIndex = 1;
            // 
            // lblvlrdinheiro
            // 
            this.lblvlrdinheiro.AutoSize = true;
            this.lblvlrdinheiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvlrdinheiro.ForeColor = System.Drawing.Color.Gold;
            this.lblvlrdinheiro.Location = new System.Drawing.Point(116, 124);
            this.lblvlrdinheiro.Name = "lblvlrdinheiro";
            this.lblvlrdinheiro.Size = new System.Drawing.Size(202, 18);
            this.lblvlrdinheiro.TabIndex = 2;
            this.lblvlrdinheiro.Text = "Digite o valor do dinheiro:";
            // 
            // lblvlrlitro
            // 
            this.lblvlrlitro.AutoSize = true;
            this.lblvlrlitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvlrlitro.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblvlrlitro.Location = new System.Drawing.Point(392, 124);
            this.lblvlrlitro.Name = "lblvlrlitro";
            this.lblvlrlitro.Size = new System.Drawing.Size(171, 18);
            this.lblvlrlitro.TabIndex = 3;
            this.lblvlrlitro.Text = "Digite o valor do litro:";
            // 
            // lblresult
            // 
            this.lblresult.AutoSize = true;
            this.lblresult.BackColor = System.Drawing.Color.SlateGray;
            this.lblresult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresult.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblresult.Location = new System.Drawing.Point(307, 22);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(0, 18);
            this.lblresult.TabIndex = 4;
            // 
            // btnresult
            // 
            this.btnresult.BackColor = System.Drawing.Color.DarkRed;
            this.btnresult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresult.ForeColor = System.Drawing.Color.GhostWhite;
            this.btnresult.Location = new System.Drawing.Point(307, 272);
            this.btnresult.Name = "btnresult";
            this.btnresult.Size = new System.Drawing.Size(120, 38);
            this.btnresult.TabIndex = 5;
            this.btnresult.Text = "RESULTADO";
            this.btnresult.UseVisualStyleBackColor = false;
            this.btnresult.Click += new System.EventHandler(this.btnresult_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Snow;
            this.panel1.Controls.Add(this.lblresult);
            this.panel1.Location = new System.Drawing.Point(-3, 346);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(771, 100);
            this.panel1.TabIndex = 6;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // EXERCICIO2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(752, 450);
            this.Controls.Add(this.btnresult);
            this.Controls.Add(this.lblvlrlitro);
            this.Controls.Add(this.lblvlrdinheiro);
            this.Controls.Add(this.txtvlrlitro);
            this.Controls.Add(this.txtvlrdinheiro);
            this.Controls.Add(this.panel1);
            this.Name = "EXERCICIO2";
            this.Text = "EXERCICIO2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtvlrdinheiro;
        private System.Windows.Forms.TextBox txtvlrlitro;
        private System.Windows.Forms.Label lblvlrdinheiro;
        private System.Windows.Forms.Label lblvlrlitro;
        private System.Windows.Forms.Label lblresult;
        private System.Windows.Forms.Button btnresult;
        private System.Windows.Forms.Panel panel1;
    }
}